#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Zipper.h"

FOUNDATION_EXPORT double ZipperVersionNumber;
FOUNDATION_EXPORT const unsigned char ZipperVersionString[];

