#import <Foundation/Foundation.h>

//! Project version number for Sodium.
FOUNDATION_EXPORT double SodiumVersionNumber;

//! Project version string for Sodium.
FOUNDATION_EXPORT const unsigned char SodiumVersionString[];

