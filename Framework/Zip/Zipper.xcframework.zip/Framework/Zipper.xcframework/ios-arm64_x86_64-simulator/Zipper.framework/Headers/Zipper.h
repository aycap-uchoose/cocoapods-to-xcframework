//
//  Zipper.h
//  Zipper
//
//  Created by Meniny on 2017-07-07.
//  Copyright © 2017年 Meniny. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>

//! Project version number for Zipper.
FOUNDATION_EXPORT double ZipperVersionNumber;

//! Project version string for Zipper.
FOUNDATION_EXPORT const unsigned char ZipperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Zipper/Zipper.h>


